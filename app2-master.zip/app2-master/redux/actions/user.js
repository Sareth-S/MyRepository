export const toggleAuth = () => ({
    type: "TOGGLE_AUTH"
});
