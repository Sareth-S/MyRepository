const Palette = {
    primary: {
        main: '#000',
        light: '#fff',
    },
    secondary: {
        main: "#e65100"
    }
}
export default Palette